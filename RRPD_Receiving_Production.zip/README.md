# RRPD Receiving — Production Build

This is the production-ready offline dashboard for Returns Logistics (RRPD Receiving). It runs entirely in the browser and stores data in LocalStorage.

## Contents
- `index.html` — main app
- `style.css` — styles
- `script.js` — application logic
- `.gitignore` and this README

## Default accounts & codes
- Default admin: **ReesW** / **DAX2025**
- Default training code: **TRAIN2025**

## How to run locally
1. Extract the files into a folder.
2. Run a simple server (recommended):
   ```bash
   cd folder
   python -m http.server 8000
   ```
3. Open `http://localhost:8000` in your browser.

## Notes
- Data is saved in LocalStorage. Use Backup JSON to export data.
- Admin-only actions archive (soft-delete) data to an internal archive you can restore from Settings.
